// --- Chat & File specific globals ---
let chatHistory = [];
let incomingFileBuffers = new Map(); // { bufferKey: { meta, chunks, receivedBytes } }

// --- Channel specific globals ---
let channels = []; // For chat channels
let currentActiveChannelId = null; // ID of the active channel


// --- Imported Sub-Modules ---
import { 
    initKanbanFeatures, 
    getKanbanData, 
    loadKanbanData, 
    resetKanbanState, 
    handleKanbanUpdate as handleKanbanUpdateInternal, 
    handleInitialKanban as handleInitialKanbanInternal,
    sendInitialKanbanStateToPeer,
    renderKanbanBoardIfActive as renderKanbanBoardIfActiveInternal
} from './kanban.js';

import { 
    initWhiteboardFeatures, 
    getWhiteboardHistory, 
    loadWhiteboardData, 
    resetWhiteboardState, 
    handleDrawCommand as handleDrawCommandInternal, 
    handleInitialWhiteboard as handleInitialWhiteboardInternal,
    sendInitialWhiteboardStateToPeer,
    redrawWhiteboardFromHistoryIfVisible as redrawWhiteboardFromHistoryIfVisibleInternal,
    resizeWhiteboardAndRedraw as resizeWhiteboardAndRedrawInternal
} from './whiteboard.js';

import { 
    initDocumentFeatures, 
    getDocumentShareData, 
    loadDocumentData, 
    resetDocumentState,
    handleInitialDocuments as handleInitialDocumentsInternal,
    handleCreateDocument as handleCreateDocumentInternal,
    handleRenameDocument as handleRenameDocumentInternal,
    handleDeleteDocument as handleDeleteDocumentInternal,
    handleDocumentContentUpdate as handleDocumentContentUpdateInternal,
    sendInitialDocumentsStateToPeer,
    renderDocumentsIfActive as renderDocumentsIfActiveInternal,
    ensureDefaultDocument as ensureDefaultDocumentInternal
} from './document.js';


// --- Dependencies from main.js (will be set in initShareFeatures) ---
let sendChatMessageDep, sendPrivateMessageDep, sendFileMetaDep, sendFileChunkDep;
let sendDrawCommandDep, sendInitialWhiteboardDep, sendKanbanUpdateDep, sendInitialKanbanDep;
let sendChatHistoryDep, sendInitialDocumentsDep, sendCreateDocumentDep, sendRenameDocumentDep;
let sendDeleteDocumentDep, sendDocumentContentUpdateDep;
let sendCreateChannelDep, onCreateChannelDep; // Retained for channel logic in share.js
let sendInitialChannelsDep, onInitialChannelsDep; // Retained for channel logic in share.js


let logStatusDep, showNotificationDep;
let localGeneratedPeerIdDep;
let getPeerNicknamesDep, getIsHostDep, getLocalNicknameDep, findPeerIdByNicknameDepFnc;
let currentRoomIdDep;

// --- DOM Elements (selected within this module, for chat and channels) ---
let chatArea, messageInput, sendMessageBtn, emojiIcon, emojiPickerPopup, triggerFileInput, chatFileInput;
let channelListDiv, newChannelNameInput, addChannelBtn; // For channels

// --- Sub-module references ---
let kanbanModuleRef, whiteboardModuleRef, documentModuleRef;


function selectChatDomElements() {
    chatArea = document.getElementById('chatArea');
    messageInput = document.getElementById('messageInput');
    sendMessageBtn = document.getElementById('sendMessageBtn');
    emojiIcon = document.querySelector('.emoji-icon');
    emojiPickerPopup = document.getElementById('emojiPickerPopup');
    triggerFileInput = document.getElementById('triggerFileInput');
    chatFileInput = document.getElementById('chatFileInput');

    channelListDiv = document.getElementById('channelList');
    newChannelNameInput = document.getElementById('newChannelNameInput');
    addChannelBtn = document.getElementById('addChannelBtn');
}

// Debounce utility (if not already available globally or via another import)
function debounce(func, delay) {
    let timeout;
    return function (...args) {
        const context = this;
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(context, args), delay);
    };
}

export function initShareFeatures(dependencies) {
    selectChatDomElements();

    // Store general dependencies
    logStatusDep = dependencies.logStatus;
    showNotificationDep = dependencies.showNotification;
    localGeneratedPeerIdDep = dependencies.localGeneratedPeerId;
    getPeerNicknamesDep = dependencies.getPeerNicknames;
    getIsHostDep = dependencies.getIsHost;
    getLocalNicknameDep = dependencies.getLocalNickname;
    findPeerIdByNicknameDepFnc = dependencies.findPeerIdByNicknameFnc;
    currentRoomIdDep = dependencies.currentRoomId;

    // Store Trystero send actions for chat/files/channels (managed by share.js)
    sendChatMessageDep = dependencies.sendChatMessage;
    sendPrivateMessageDep = dependencies.sendPrivateMessage;
    sendFileMetaDep = dependencies.sendFileMeta;
    sendFileChunkDep = dependencies.sendFileChunk;
    sendChatHistoryDep = dependencies.sendChatHistory;
    sendCreateChannelDep = dependencies.sendCreateChannel;
    // onCreateChannelDep = dependencies.onCreateChannel; // This is a receiver, handled by main.js
    sendInitialChannelsDep = dependencies.sendInitialChannels;
    // onInitialChannelsDep = dependencies.onInitialChannels; // Receiver

    // Store Trystero send actions for sub-modules
    sendDrawCommandDep = dependencies.sendDrawCommand;
    sendInitialWhiteboardDep = dependencies.sendInitialWhiteboard;
    sendKanbanUpdateDep = dependencies.sendKanbanUpdate;
    sendInitialKanbanDep = dependencies.sendInitialKanban;
    sendInitialDocumentsDep = dependencies.sendInitialDocuments;
    sendCreateDocumentDep = dependencies.sendCreateDocument;
    sendRenameDocumentDep = dependencies.sendRenameDocument;
    sendDeleteDocumentDep = dependencies.sendDeleteDocument;
    sendDocumentContentUpdateDep = dependencies.sendDocumentContentUpdate;

    // Initialize sub-modules
    const commonSubModuleDeps = {
        logStatus: logStatusDep,
        showNotification: showNotificationDep,
        getPeerNicknames: getPeerNicknamesDep,
        localGeneratedPeerId: localGeneratedPeerIdDep,
        getIsHost: getIsHostDep,
    };

    kanbanModuleRef = initKanbanFeatures({
        ...commonSubModuleDeps,
        sendKanbanUpdate: sendKanbanUpdateDep,
        sendInitialKanban: sendInitialKanbanDep, // Pass for consistency, though sending initial state is coordinated by share.js
    });

    whiteboardModuleRef = initWhiteboardFeatures({
        ...commonSubModuleDeps,
        sendDrawCommand: sendDrawCommandDep,
        sendInitialWhiteboard: sendInitialWhiteboardDep, // Pass for consistency
    });

    documentModuleRef = initDocumentFeatures({
        ...commonSubModuleDeps,
        sendInitialDocuments: sendInitialDocumentsDep, // Pass for consistency
        sendCreateDocument: sendCreateDocumentDep,
        sendRenameDocument: sendRenameDocumentDep,
        sendDeleteDocument: sendDeleteDocumentDep,
        sendDocumentContentUpdate: sendDocumentContentUpdateDep,
    });
    
    initChat(); // Initialize chat features (uses share.js level deps)
    
    // Handle imported workspace state
    const importedState = dependencies.getImportedWorkspaceState();
    if (importedState && getIsHostDep && getIsHostDep()) {
        // Load data into each module
        loadChatHistoryFromImport(importedState.chatHistory || []);
        if (importedState.channels) {
            channels = importedState.channels;
            currentActiveChannelId = importedState.currentActiveChannelIdForImport || (channels.length > 0 ? channels[0].id : null);
        }
        if (whiteboardModuleRef) whiteboardModuleRef.loadWhiteboardData(importedState.whiteboardHistory || []);
        if (kanbanModuleRef) kanbanModuleRef.loadKanbanData(importedState.kanbanData || { columns: [] });
        if (documentModuleRef) documentModuleRef.loadDocumentData(importedState.documents || [], importedState.currentActiveDocumentId);
        
        if(dependencies.clearImportedWorkspaceState) dependencies.clearImportedWorkspaceState();
    }
    
    // Ensure default channel/document if host and nothing loaded/exists
    if (getIsHostDep && getIsHostDep()) {
        if (channels.length === 0) {
            _createAndBroadcastChannel("#general", true);
        }
        if (documentModuleRef) documentModuleRef.ensureDefaultDocument(); // ensureDefaultDocument now in document.js
    } else if (channels.length > 0 && !currentActiveChannelId) {
        // If client and channels exist but no active one, set first as active
        setActiveChannel(channels[0].id, false);
    }


    renderChannelList();
    displayChatForCurrentChannel();

    return { 
        // Chat specific handlers
        handleChatMessage, handlePrivateMessage, handleFileMeta, handleFileChunk,
        handleChatHistory, 
        handleCreateChannel, handleInitialChannels, // Channel handlers managed by share.js

        // Sub-module handlers (delegated)
        handleDrawCommand: (data, peerId) => whiteboardModuleRef.handleDrawCommand(data, peerId),
        handleInitialWhiteboard: (data, peerId) => whiteboardModuleRef.handleInitialWhiteboard(data, peerId, getIsHostDep),
        handleKanbanUpdate: (data, peerId) => kanbanModuleRef.handleKanbanUpdate(data, peerId, localGeneratedPeerIdDep),
        handleInitialKanban: (data, peerId) => kanbanModuleRef.handleInitialKanban(data, peerId, getIsHostDep, localGeneratedPeerIdDep),
        handleInitialDocuments: (data, peerId) => documentModuleRef.handleInitialDocuments(data, peerId),
        handleCreateDocument: (data, peerId) => documentModuleRef.handleCreateDocument(data, peerId),
        handleRenameDocument: (data, peerId) => documentModuleRef.handleRenameDocument(data, peerId),
        handleDeleteDocument: (data, peerId) => documentModuleRef.handleDeleteDocument(data, peerId),
        handleDocumentContentUpdate: (data, peerId) => documentModuleRef.handleDocumentContentUpdate(data, peerId),
        
        // UI interaction methods (delegated)
        redrawWhiteboardFromHistoryIfVisible: (force) => whiteboardModuleRef.redrawWhiteboardFromHistoryIfVisible(force),
        resizeWhiteboardAndRedraw: () => whiteboardModuleRef.resizeWhiteboardAndRedraw(),
        renderKanbanBoardIfActive: (force) => kanbanModuleRef.renderKanbanBoardIfActive(force),
        renderDocumentsIfActive: (force) => documentModuleRef.renderDocumentsIfActive(force),
        ensureDefaultDocument: () => documentModuleRef.ensureDefaultDocument(), // Keep for main.js if needed during setup
        
        // Share.js specific methods
        sendFullStateToPeer,
        displaySystemMessage,
        updateChatMessageInputPlaceholder, // Stays in share.js as it relates to active channel
        primePrivateMessage,
        hideEmojiPicker,
        initializeEmojiPicker,
        setShareModulePeerInfo, // General, stays in share.js
        handleShareModulePeerLeave // General, stays in share.js
    };
}

export function setShareModulePeerInfo(peerNicknames) {
    // This function is a placeholder in original code, can be expanded if needed.
    // Currently, peerNicknames are accessed via getPeerNicknamesDep() by sub-modules.
}

export function handleShareModulePeerLeave(peerId) {
    // File transfer cancellation logic (chat-related)
    const keysToDelete = [];
    for (const [key, value] of incomingFileBuffers.entries()) {
        if (key.startsWith(`${peerId}_`)) {
            const peerNickname = (getPeerNicknamesDep && getPeerNicknamesDep()[peerId]) ? getPeerNicknamesDep()[peerId] : peerId.substring(0,6);
            if(logStatusDep) logStatusDep(`File transfer for ${value.meta.name} from departing peer ${peerNickname} cancelled.`);
            
            const safeSenderNickname = peerNickname.replace(/\W/g, '');
            const safeFileName = value.meta.name.replace(/\W/g, '');
            const progressId = `file-progress-${safeSenderNickname}-${safeFileName}`;
            const progressElem = document.getElementById(progressId);
            if (progressElem) progressElem.textContent = ` (Cancelled)`;
            keysToDelete.push(key);
        }
    }
    keysToDelete.forEach(key => incomingFileBuffers.delete(key));

    // Potentially notify sub-modules if they need to clean up peer-specific data not tied to Trystero streams
    // (Trystero onPeerLeave handles stream cleanup, which media.js uses)
}


// --- Chat Feature (and Channels, File Sharing) ---
function initChat() {
    if (!sendMessageBtn || !messageInput || !triggerFileInput || !chatFileInput || !emojiIcon || !emojiPickerPopup) return;
    if (!addChannelBtn || !newChannelNameInput || !channelListDiv) return; 

    sendMessageBtn.addEventListener('click', handleSendMessage);
    messageInput.addEventListener('keypress', (e) => { if (e.key === 'Enter') handleSendMessage(); });

    triggerFileInput.addEventListener('click', () => chatFileInput.click());
    chatFileInput.addEventListener('change', handleChatFileSelected);

    emojiIcon.addEventListener('click', (event) => {
        event.stopPropagation();
        const isHidden = emojiPickerPopup.classList.toggle('hidden');
        if (!isHidden && emojiPickerPopup.children.length === 0) {
            populateEmojiPicker();
        }
        messageInput.focus();
    });
    document.addEventListener('click', (event) => {
        if (emojiPickerPopup && !emojiPickerPopup.classList.contains('hidden') && !emojiPickerPopup.contains(event.target) && event.target !== emojiIcon) {
            emojiPickerPopup.classList.add('hidden');
        }
    });
    addChannelBtn.addEventListener('click', handleAddChannelUI);
}

export function initializeEmojiPicker() {
    if(emojiPickerPopup && emojiPickerPopup.children.length === 0) populateEmojiPicker();
}

function populateEmojiPicker() {
    if (!emojiPickerPopup) return;
    emojiPickerPopup.innerHTML = '';
    const emojis = ['😊', '😂', '❤️', '👍', '🙏', '🎉', '🔥', '👋', '✅', '🤔', '😢', '😮', '😭', '😍', '💯', '🌟', '✨', '🎁', '🎈', '🎂', '🍕', '🚀', '💡', '🤷', '🤦'];
    emojis.forEach(emoji => {
        const emojiSpan = document.createElement('span');
        emojiSpan.textContent = emoji;
        emojiSpan.setAttribute('role', 'button');
        emojiSpan.title = `Insert ${emoji}`;
        emojiSpan.addEventListener('click', () => {
            insertEmojiIntoInput(emoji);
            emojiPickerPopup.classList.add('hidden');
        });
        emojiPickerPopup.appendChild(emojiSpan);
    });
}

function insertEmojiIntoInput(emoji) {
    if (!messageInput) return;
    const cursorPos = messageInput.selectionStart;
    const textBefore = messageInput.value.substring(0, cursorPos);
    const textAfter = messageInput.value.substring(cursorPos);
    messageInput.value = textBefore + emoji + textAfter;
    messageInput.focus();
    const newCursorPos = cursorPos + emoji.length;
    messageInput.setSelectionRange(newCursorPos, newCursorPos);
}

export function hideEmojiPicker() {
    if(emojiPickerPopup) emojiPickerPopup.classList.add('hidden');
}

function _createAndBroadcastChannel(channelName, isDefault = false) {
    if (!channelName || !channelName.trim()) return null;
    let saneChannelName = channelName.trim();
    if (!saneChannelName.startsWith('#')) {
        saneChannelName = '#' + saneChannelName;
    }
    saneChannelName = saneChannelName.replace(/\s+/g, '-').toLowerCase(); 

    if (channels.find(ch => ch.name === saneChannelName)) {
        if(logStatusDep && !isDefault) logStatusDep(`Channel "${saneChannelName}" already exists.`, true);
        return null;
    }

    const newChannel = { id: `ch-${Date.now()}-${Math.random().toString(36).substring(2,5)}`, name: saneChannelName };
    channels.push(newChannel);
    
    if (sendCreateChannelDep) {
        sendCreateChannelDep(newChannel); 
    }
    if (isDefault || channels.length === 1) { 
        setActiveChannel(newChannel.id, false);
    }
    renderChannelList();
    return newChannel;
}


function handleAddChannelUI() {
    if (!newChannelNameInput) return;
    const channelName = newChannelNameInput.value;
    const createdChannel = _createAndBroadcastChannel(channelName);
    if (createdChannel) {
        newChannelNameInput.value = '';
        if(logStatusDep) logStatusDep(`Channel "${createdChannel.name}" created.`);
    }
}

function renderChannelList() {
    if (!channelListDiv) return;
    channelListDiv.innerHTML = '';
    channels.forEach(channel => {
        const channelItem = document.createElement('div');
        channelItem.classList.add('channel-list-item');
        channelItem.textContent = channel.name;
        channelItem.dataset.channelId = channel.id;
        if (channel.id === currentActiveChannelId) {
            channelItem.classList.add('active');
        }
        channelItem.addEventListener('click', () => setActiveChannel(channel.id));

        const notifDot = document.createElement('span');
        notifDot.classList.add('channel-notification-dot', 'hidden'); 
        channelItem.appendChild(notifDot);

        channelListDiv.appendChild(channelItem);
    });
}

function setActiveChannel(channelId, clearNotifications = true) {
    if (currentActiveChannelId === channelId && !clearNotifications) { // Already active, maybe just re-render if needed due to notif change
        renderChannelList(); // Ensure correct active state visually if called with clearNotifications=false
        return;
    }
    currentActiveChannelId = channelId;
    renderChannelList(); 
    displayChatForCurrentChannel();

    if (clearNotifications && channelListDiv) { 
        const channelDot = channelListDiv.querySelector(`.channel-list-item[data-channel-id="${channelId}"] .channel-notification-dot`);
        if (channelDot) {
            channelDot.classList.add('hidden');
        }
    }
    if(messageInput) { // Update placeholder
        const activeChannel = channels.find(c=>c.id === channelId);
        messageInput.placeholder = `Message ${activeChannel?.name || (currentRoomIdDep || '')}`;
    }
}

function displayChatForCurrentChannel() {
    if (!chatArea) return;
    chatArea.innerHTML = '';
    if (!currentActiveChannelId && chatHistory.some(msg => !msg.channelId && !msg.pmInfo && !msg.fileMeta && !msg.isSystem)) {
        // This case is unlikely if we always have a default channel.
        // If there's no active channel, but there are "global" messages (e.g. system messages before channel assignment)
        // decide if they should be shown or if an active channel is strictly required.
        // For now, assume an active channel is needed for non-PM/File/System messages.
    }
    const messagesForChannel = chatHistory.filter(msg => 
        msg.channelId === currentActiveChannelId || // Messages for the current channel
        (!msg.channelId && (msg.pmInfo || msg.fileMeta || msg.isSystem)) // PMs, Files, System messages are global or tied to implicit context
    );
    messagesForChannel.forEach(msg => {
        // Double check if the message should indeed be displayed
        // (e.g. PMs/Files/System msgs are always relevant if they are in chatHistory)
        // Channel messages only if they match currentActiveChannelId
         if ( (msg.channelId && msg.channelId === currentActiveChannelId) || msg.pmInfo || msg.fileMeta || msg.isSystem ) {
            displayMessage(msg, msg.senderPeerId === localGeneratedPeerIdDep, msg.isSystem);
        }
    });
    chatArea.scrollTop = chatArea.scrollHeight;
}


function displayMessage(msgObject, isSelf = false, isSystem = false) {
    if (!chatArea) return;
    const { senderNickname, message, pmInfo, fileMeta, timestamp } = msgObject;
    const messageDiv = document.createElement('div'); messageDiv.classList.add('message');
    const displayTimestamp = timestamp ? new Date(timestamp) : new Date();
    const hours = String(displayTimestamp.getHours()).padStart(2, '0');
    const minutes = String(displayTimestamp.getMinutes()).padStart(2, '0');
    const timestampStr = `${hours}:${minutes}`;
    const timestampSpan = document.createElement('span'); timestampSpan.classList.add('timestamp'); timestampSpan.textContent = timestampStr;

    if (isSystem) {
        messageDiv.classList.add('system-message');
        messageDiv.appendChild(document.createTextNode(message + " "));
    } else if (pmInfo) {
        messageDiv.classList.add('pm');
        messageDiv.classList.add(isSelf ? 'self' : 'other');
        const pmContextSpan = document.createElement('span');
        pmContextSpan.classList.add('pm-info');
        pmContextSpan.textContent = pmInfo.type === 'sent' ? `To ${pmInfo.recipient}:` : `From ${pmInfo.sender}:`;
        messageDiv.appendChild(pmContextSpan);
        messageDiv.appendChild(document.createTextNode(message + " "));
    } else if (fileMeta) {
        messageDiv.classList.add(isSelf ? 'self' : 'other');
        messageDiv.classList.add('file-message');
        const senderSpan = document.createElement('span'); senderSpan.classList.add('sender');
        senderSpan.textContent = isSelf ? 'You' : senderNickname;
        messageDiv.appendChild(senderSpan);
        const fileInfoSpan = document.createElement('span');
        fileInfoSpan.innerHTML = `Shared a file: <strong>${fileMeta.name}</strong> (${(fileMeta.size / 1024).toFixed(2)} KB) `;
        messageDiv.appendChild(fileInfoSpan);
        if (fileMeta.blobUrl) {
            const downloadLink = document.createElement('a');
            downloadLink.href = fileMeta.blobUrl;
            downloadLink.download = fileMeta.name;
            downloadLink.textContent = 'Download';
            messageDiv.appendChild(downloadLink);
        } else if (fileMeta.receiving) {
            const progressSpan = document.createElement('span');
            const safeSenderNickname = senderNickname ? senderNickname.replace(/\W/g, '') : 'unknownsender';
            const safeFileName = fileMeta.name ? fileMeta.name.replace(/\W/g, '') : 'unknownfile';
            progressSpan.id = `file-progress-${safeSenderNickname}-${safeFileName}`;
            progressSpan.textContent = ` (Receiving 0%)`;
            messageDiv.appendChild(progressSpan);
        }
    } else { // Regular channel message
        messageDiv.classList.add(isSelf ? 'self' : 'other');
        const senderSpan = document.createElement('span'); senderSpan.classList.add('sender');
        senderSpan.textContent = isSelf ? 'You' : senderNickname;
        messageDiv.appendChild(senderSpan);
        messageDiv.appendChild(document.createTextNode(message + " "));
    }

    messageDiv.appendChild(timestampSpan);
    chatArea.appendChild(messageDiv);
    chatArea.scrollTop = chatArea.scrollHeight;
}

function addMessageToHistoryAndDisplay(msgData, isSelf = false, isSystem = false) {
    let channelIdForMsg = msgData.channelId; // Use provided channelId if any
    // If it's a self message, not system, not PM, not File, and no channelId is set, assign current active channel
    if (isSelf && !isSystem && !msgData.pmInfo && !msgData.fileMeta && !channelIdForMsg) {
        channelIdForMsg = currentActiveChannelId;
    }

    const fullMsgObject = {
        ...msgData,
        channelId: channelIdForMsg, // Ensure channelId is part of the object
        timestamp: msgData.timestamp || Date.now(),
        senderPeerId: isSelf ? localGeneratedPeerIdDep : msgData.senderPeerId // Ensure senderPeerId is set
    };
    chatHistory.push(fullMsgObject);

    // Display logic:
    // If it's a system message, always display.
    // If it's a PM or File message, always display (as they aren't tied to a specific channel view beyond chat history).
    // If it's a regular channel message, display only if its channelId matches the currentActiveChannelId.
    if ( isSystem || fullMsgObject.pmInfo || fullMsgObject.fileMeta || (fullMsgObject.channelId && fullMsgObject.channelId === currentActiveChannelId) ) {
        displayMessage(fullMsgObject, isSelf, isSystem);
    }
}

function handleSendMessage() {
    const messageText = messageInput.value.trim();
    if (!messageText || !sendChatMessageDep) return;
    const timestamp = Date.now();
    const localCurrentNickname = getLocalNicknameDep ? getLocalNicknameDep() : 'You';

    if (messageText.toLowerCase().startsWith('/pm ')) {
         const parts = messageText.substring(4).split(' ');
        const targetNickname = parts.shift();
        const pmContent = parts.join(' ').trim();
        if (!targetNickname || !pmContent) {
            addMessageToHistoryAndDisplay({ message: "Usage: /pm <nickname> <message>", timestamp }, false, true); return;
        }
        if (targetNickname.toLowerCase() === localCurrentNickname.toLowerCase()) {
            addMessageToHistoryAndDisplay({ message: "You can't PM yourself.", timestamp }, false, true); return;
        }
        const targetPeerId = findPeerIdByNicknameDepFnc ? findPeerIdByNicknameDepFnc(targetNickname) : null;
        if (targetPeerId && sendPrivateMessageDep) {
            sendPrivateMessageDep({ content: pmContent, timestamp }, targetPeerId);
            // PMs are not tied to a channel, so channelId is null/undefined here
            addMessageToHistoryAndDisplay({ senderNickname: localCurrentNickname, message: pmContent, pmInfo: { type: 'sent', recipient: targetNickname }, timestamp }, true);
        } else {
            addMessageToHistoryAndDisplay({ message: `User "${targetNickname}" not found or PM failed.`, timestamp }, false, true);
        }
    } else { // Regular channel message
        if (!currentActiveChannelId) {
            addMessageToHistoryAndDisplay({ message: "Please select a channel to send a message.", timestamp }, false, true);
            return;
        }
        const msgData = { message: messageText, timestamp, channelId: currentActiveChannelId };
        sendChatMessageDep(msgData);
        addMessageToHistoryAndDisplay({ senderNickname: localCurrentNickname, ...msgData }, true);
    }
    messageInput.value = '';
    if (emojiPickerPopup && !emojiPickerPopup.classList.contains('hidden')) emojiPickerPopup.classList.add('hidden');
}

async function handleChatFileSelected(event) {
    const file = event.target.files[0];
    if (!file || !sendFileMetaDep || !sendFileChunkDep) return;
    const localCurrentNickname = getLocalNicknameDep ? getLocalNicknameDep() : 'You';

    if(logStatusDep) logStatusDep(`Preparing to send file: ${file.name}`);
    const fileMeta = { name: file.name, type: file.type, size: file.size, id: Date.now().toString() };
    
    // File messages are not tied to a specific channel in the same way regular chat messages are.
    // They appear in the chat history globally (or filtered by PM context if that feature is added).
    // So, channelId is typically null/undefined for fileMeta messages.
    addMessageToHistoryAndDisplay({ senderNickname: localCurrentNickname, fileMeta: { ...fileMeta, receiving: true } }, true);
    
    sendFileMetaDep(fileMeta); 

    const CHUNK_SIZE = 16 * 1024;
    let offset = 0;
    const reader = new FileReader();

    reader.onload = (e) => {
        const chunkData = e.target.result;
        const isFinal = (offset + chunkData.byteLength) >= file.size;
        sendFileChunkDep(chunkData, null, { fileName: fileMeta.name, fileId: fileMeta.id, final: isFinal });
        
        const safeLocalNickname = localCurrentNickname.replace(/\W/g, '');
        const safeFileName = fileMeta.name.replace(/\W/g, '');
        const progressId = `file-progress-${safeLocalNickname}-${safeFileName}`;

        const progressElem = document.getElementById(progressId);
        if (progressElem) {
            progressElem.textContent = ` (Sending ${Math.min(100, Math.round(((offset + chunkData.byteLength) / file.size) * 100))}%)`;
        }

        if (!isFinal) {
            offset += chunkData.byteLength;
            readNextChunk();
        } else {
            if(logStatusDep) logStatusDep(`File ${file.name} sent.`);
            if (progressElem) progressElem.textContent = ` (Sent 100%)`;
        }
    };
    reader.onerror = (error) => {
        if(logStatusDep) logStatusDep(`Error reading file: ${error}`, true);
        const safeLocalNickname = localCurrentNickname.replace(/\W/g, '');
        const safeFileName = fileMeta.name.replace(/\W/g, '');
        const progressId = `file-progress-${safeLocalNickname}-${safeFileName}`;
        const progressElem = document.getElementById(progressId);
        if (progressElem) progressElem.textContent = ` (Error sending)`;
    };
    function readNextChunk() {
        const slice = file.slice(offset, offset + CHUNK_SIZE);
        reader.readAsArrayBuffer(slice);
    }
    readNextChunk();
    chatFileInput.value = '';
}

export function handleChatMessage(msgData, peerId) {
    const senderNickname = (getPeerNicknamesDep && getPeerNicknamesDep()[peerId]) ? getPeerNicknamesDep()[peerId] : `Peer ${peerId.substring(0, 6)}`;
    const fullMsgObject = { ...msgData, senderNickname, senderPeerId: peerId, timestamp: msgData.timestamp || Date.now() };
    
    chatHistory.push(fullMsgObject); // Add to global history

    // Display if current channel matches, or notify for other channels
    if (fullMsgObject.channelId === currentActiveChannelId) {
        displayMessage(fullMsgObject, false);
    } else if (fullMsgObject.channelId && channelListDiv) { // It's for another channel
        const channelDot = channelListDiv.querySelector(`.channel-list-item[data-channel-id="${fullMsgObject.channelId}"] .channel-notification-dot`);
        if (channelDot) {
            channelDot.classList.remove('hidden');
        }
    }
    if (peerId !== localGeneratedPeerIdDep && showNotificationDep) showNotificationDep('chatSection');
}
export function handlePrivateMessage(pmData, senderPeerId) {
    const sender = (getPeerNicknamesDep && getPeerNicknamesDep()[senderPeerId]) ? getPeerNicknamesDep()[senderPeerId] : `Peer ${senderPeerId.substring(0, 6)}`;
    // PMs are not tied to a channel, channelId is null/undefined
    addMessageToHistoryAndDisplay({ senderNickname: sender, message: pmData.content, pmInfo: { type: 'received', sender: sender }, senderPeerId: senderPeerId, timestamp: pmData.timestamp || Date.now() }, false);
    if (senderPeerId !== localGeneratedPeerIdDep && showNotificationDep) showNotificationDep('chatSection'); 
}
export function handleFileMeta(meta, peerId) {
    const senderNickname = (getPeerNicknamesDep && getPeerNicknamesDep()[peerId]) ? getPeerNicknamesDep()[peerId] : `Peer ${peerId.substring(0, 6)}`;
    const bufferKey = `${peerId}_${meta.id}`;
    incomingFileBuffers.set(bufferKey, { meta, chunks: [], receivedBytes: 0 });
    // File meta messages are not tied to a channel, channelId is null/undefined
    addMessageToHistoryAndDisplay({ senderNickname, fileMeta: { ...meta, receiving: true }, senderPeerId: peerId, timestamp: Date.now() }, false);
    if(logStatusDep) logStatusDep(`${senderNickname} is sending file: ${meta.name}`);
    if (peerId !== localGeneratedPeerIdDep && showNotificationDep) showNotificationDep('chatSection');
}
export function handleFileChunk(chunk, peerId, chunkMeta) {
    const senderNickname = (getPeerNicknamesDep && getPeerNicknamesDep()[peerId]) ? getPeerNicknamesDep()[peerId] : `Peer ${peerId.substring(0, 6)}`;
    const bufferKey = `${peerId}_${chunkMeta.fileId}`;
    const fileBuffer = incomingFileBuffers.get(bufferKey);

    if (fileBuffer) {
        fileBuffer.chunks.push(chunk);
        fileBuffer.receivedBytes += chunk.byteLength;
        const progress = Math.round((fileBuffer.receivedBytes / fileBuffer.meta.size) * 100);

        const safeSenderNickname = senderNickname.replace(/\W/g, '');
        const safeFileName = fileBuffer.meta.name.replace(/\W/g, '');
        const progressId = `file-progress-${safeSenderNickname}-${safeFileName}`;
        const progressElem = document.getElementById(progressId);
        if (progressElem) progressElem.textContent = ` (Receiving ${progress}%)`;

        if (chunkMeta.final || fileBuffer.receivedBytes >= fileBuffer.meta.size) {
            const completeFile = new Blob(fileBuffer.chunks, { type: fileBuffer.meta.type });
            const blobUrl = URL.createObjectURL(completeFile);

            if (chatArea) {
                // Update the existing file message to include a download link
                chatArea.querySelectorAll('.message.other.file-message').forEach(msgDiv => {
                    const senderSpan = msgDiv.querySelector('.sender');
                    const fileInfoStrong = msgDiv.querySelector('strong');
                    if (senderSpan && senderSpan.textContent === senderNickname && fileInfoStrong && fileInfoStrong.textContent === fileBuffer.meta.name) {
                        const existingProgress = msgDiv.querySelector(`#${progressId}`);
                        if (existingProgress) existingProgress.remove(); // Remove progress text
                        
                        let downloadLink = msgDiv.querySelector('a');
                        if (!downloadLink) { // Create if not exists (shouldn't happen often)
                            downloadLink = document.createElement('a');
                            msgDiv.appendChild(document.createTextNode(" ")); // Add space before link
                            msgDiv.appendChild(downloadLink);
                        }
                        downloadLink.href = blobUrl;
                        downloadLink.download = fileBuffer.meta.name;
                        downloadLink.textContent = 'Download';
                    }
                });
            }
            if(logStatusDep) logStatusDep(`File ${fileBuffer.meta.name} from ${senderNickname} received.`);
            incomingFileBuffers.delete(bufferKey);
        }
    } else {
        console.warn(`Received chunk for unknown file: ${chunkMeta.fileName} from ${senderNickname}`);
    }
}
export function handleChatHistory(history, peerId) {
    if (getIsHostDep && !getIsHostDep()) { // Only non-hosts process this
        chatHistory = history;
        if (currentActiveChannelId) { // If a channel is active, re-display its chat
            displayChatForCurrentChannel();
        }
        if(logStatusDep) logStatusDep(`Received chat history from ${(getPeerNicknamesDep && getPeerNicknamesDep()[peerId]) ? getPeerNicknamesDep()[peerId] : 'host'}.`);
    }
}
export function updateChatMessageInputPlaceholder() { // Now takes no args, uses currentActiveChannelId
    if(messageInput) {
        const activeChannel = channels.find(c => c.id === currentActiveChannelId);
        messageInput.placeholder = `Message ${activeChannel?.name || (currentRoomIdDep || 'current channel')}`;
    }
}
export function primePrivateMessage(nickname) {
    if (messageInput) {
        messageInput.value = `/pm ${nickname} `;
        messageInput.focus();
    }
}

// --- Channel Handlers (managed by share.js) ---
export function handleCreateChannel(newChannelData, peerId) {
    if (!channels.find(ch => ch.id === newChannelData.id)) { // Avoid duplicates
        channels.push(newChannelData);
        renderChannelList();
        if (peerId !== localGeneratedPeerIdDep && logStatusDep) {
            const senderName = (getPeerNicknamesDep && getPeerNicknamesDep()[peerId]) ? getPeerNicknamesDep()[peerId] : 'another user';
            logStatusDep(`Channel "${newChannelData.name}" created by ${senderName}.`);
        }
        if (!currentActiveChannelId && channels.length === 1) { // If it's the first channel, auto-activate
            setActiveChannel(newChannelData.id, false);
        }
    }
}

export function handleInitialChannels(receivedChannels, peerId) {
    if (getIsHostDep && !getIsHostDep()) { // Only non-hosts process this
        channels = receivedChannels || [];
        if (channels.length > 0 && !currentActiveChannelId) {
            currentActiveChannelId = channels[0].id; // Default to first channel if none active
        }
        renderChannelList();
        if (chatHistory.length > 0) { // If chat history was already received, ensure it's displayed for the (newly) active channel
             displayChatForCurrentChannel();
        }
        if(logStatusDep) logStatusDep(`Received channel list from ${(getPeerNicknamesDep && getPeerNicknamesDep()[peerId]) ? getPeerNicknamesDep()[peerId] : 'host'}.`);
    }
}


// --- Data Export/Import/Sync ---
export function getShareableData() {
    // Ensure current document edits are captured if document module is loaded
    if (documentModuleRef) documentModuleRef.getDocumentShareData(); // This updates internal state

    return { 
        chatHistory, 
        channels, 
        currentActiveChannelIdForImport: currentActiveChannelId, // Use a distinct key for import to avoid confusion
        whiteboardHistory: whiteboardModuleRef ? whiteboardModuleRef.getWhiteboardHistory() : [], 
        kanbanData: kanbanModuleRef ? kanbanModuleRef.getKanbanData() : { columns: [] }, 
        documents: documentModuleRef ? documentModuleRef.getDocumentShareData().docs : [], 
        currentActiveDocumentId: documentModuleRef ? documentModuleRef.getDocumentShareData().activeId : null,
    };
}
export function loadShareableData(data) { 
    // Chat and Channel data (managed by share.js)
    chatHistory = data.chatHistory || [];
    channels = data.channels || [];
    currentActiveChannelId = data.currentActiveChannelIdForImport || (channels.length > 0 ? channels[0].id : null);

    // Sub-module data
    if (whiteboardModuleRef) whiteboardModuleRef.loadWhiteboardData(data.whiteboardHistory || []);
    if (kanbanModuleRef) kanbanModuleRef.loadKanbanData(data.kanbanData || { columns: [] });
    if (documentModuleRef) documentModuleRef.loadDocumentData(data.documents || [], data.currentActiveDocumentId);
    
    // After loading, render relevant UI
    renderChannelList();
    displayChatForCurrentChannel();
    // Sub-modules will typically render themselves upon receiving initial data or when their section becomes active
}
function loadChatHistoryFromImport(importedHistory) { 
    chatHistory = importedHistory; 
    // displayChatForCurrentChannel(); // This will be called by loadShareableData or init
}


export function sendFullStateToPeer(peerId) {
    if (getIsHostDep && getIsHostDep()) {
        // Channels and Chat History (managed by share.js)
        if (sendInitialChannelsDep) sendInitialChannelsDep(channels, peerId);
        if (sendChatHistoryDep && chatHistory.length > 0) sendChatHistoryDep(chatHistory, peerId);
        
        // Sub-module states
        if (whiteboardModuleRef) whiteboardModuleRef.sendInitialWhiteboardStateToPeer(peerId, getIsHostDep);
        if (kanbanModuleRef) kanbanModuleRef.sendInitialKanbanStateToPeer(peerId, getIsHostDep);
        if (documentModuleRef) documentModuleRef.sendInitialDocumentsStateToPeer(peerId, getIsHostDep);
    }
}

export function displaySystemMessage(message) {
    // System messages are not tied to a specific channel for filtering, but are stored with one for context if available
    const channelIdForSystem = currentActiveChannelId || 'system-global'; // Use active channel if available, else a generic ID
    addMessageToHistoryAndDisplay({ message, timestamp: Date.now(), channelId: channelIdForSystem }, false, true);
}

export function resetShareModuleStates(isCreatingHost = false) {
    // Reset chat and channel state (managed by share.js)
    chatHistory = [];
    if (chatArea) chatArea.innerHTML = '';
    if (messageInput) messageInput.value = '';
    incomingFileBuffers.clear();

    channels = [];
    currentActiveChannelId = null;
    if(channelListDiv) channelListDiv.innerHTML = '';
    if(newChannelNameInput) newChannelNameInput.value = '';


    // Reset sub-module states
    if (whiteboardModuleRef) whiteboardModuleRef.resetWhiteboardState();
    if (kanbanModuleRef) kanbanModuleRef.resetKanbanState();
    if (documentModuleRef) documentModuleRef.resetDocumentState();
    
}